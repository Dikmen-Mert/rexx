<!DOCTYPE html>
<html>
<head>
    <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
    </script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">


    <script src=
            "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
    </script>

    <style>
        .box {
            padding: 20px;
            margin-top: 50px;
        }
        .w-100{
            width: 100%;
        }
    </style>
</head>

<body>
<?php
$index = $_GET['index'];

$data = file_get_contents('Sale.json');
$data_array = json_decode($data);

$row = $data_array[$index];

if(isset($_POST['save'])){
    $input = array(
        'sale_id' => $_POST['sale_id'],
        'customer_name' => $_POST['customer_name'],
        'customer_mail' => $_POST['customer_mail'],
        'product_id' => $_POST['product_id'],
        'product_name' => $_POST['product_name'],
        'product_price' => $_POST['product_price'],
        'sale_date' => $_POST['sale_date']
    );

    //update the selected index
    $data_array[$index] = $input;

    //encode back to json
    $data = json_encode($data_array, JSON_PRETTY_PRINT);
    file_put_contents('Sale.json', $data);

    header('location: index.php');
}
?>
<div class="container">
    <div class="row">
        <div class="col-1"></div>
        <div class="col-8"><a class="btn btn-danger" href="index.php">Back</a>
            <form method="POST">
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Sale ID</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="sale_id" name="sale_id" value="<?php echo $row->sale_id; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Customer Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo $row->customer_name; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Customer E-mail</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="customer_mail" name="customer_mail" value="<?php echo $row->customer_mail; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Product ID</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="product_id" name="product_id" value="<?php echo $row->product_id; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Product Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo $row->product_name; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Product Price</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="product_price" name="product_price" value="<?php echo $row->product_price; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Sale Date</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="sale_date" name="sale_date" type="datetime-local" value="<?php echo $row->sale_date; ?>"
                               name="meeting-time" value="2018-06-12T19:30"
                               min="2000-06-07T00:00" max="2036-06-14T00:00" >
                    </div>
                </div>

                <input type="submit" name="save" value="Save" class="btn btn-primary">
            </form>

        </div>
        <div class="col-5"></div>
    </div>
</div>
</body>
</html>