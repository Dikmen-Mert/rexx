<!DOCTYPE html>
<html>

<head>
    <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
    </script>

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">

    <script src=
            "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
    </script>

    <style>
        .box {
            padding: 20px;
            margin-top: 50px;
        }
        .w-100{
            width: 100%;
        }
    </style>
</head>

<body>
<div class="container-fluid box">
    <?php

    $connect = mysqli_connect("localhost", "root", "", "sales_db");

    $query = '';
    $table_data = '';
    $filename = "Sale.json";
    $data = file_get_contents($filename);
    $array = json_decode($data, true);

    $total_price=0;
    $index=0;
    foreach($array as $row) {
        $query .=
            "INSERT INTO sales VALUES
				('".$row["sale_id"]."','".$row["customer_name"]."', '".$row["customer_mail"]."',
				'".$row["product_id"]."', '".$row["product_name"]."',
				 '".$row["product_price"]."', '".$row["sale_date"]."'); ";

        $table_data .= '
				<tr>
					<td>'.$row["sale_id"].'</td>
					<td>'.$row["customer_name"].'</td>
					<td>'.$row["customer_mail"].'</td>
					<td>'.$row["product_id"].'</td>
					<td>'.$row["product_name"].'</td>
					<td>'.$row["product_price"].'€</td>
					<td>'.$row["sale_date"].'</td>
					<td>
					<a href="edit.php?index='.$index.'" class="btn btn-success w-100 btn-sm">Edit</a>
					<a href="delete.php?index='.$index.'" class="btn btn-danger w-100 btn-sm">Delete</a>
					</td>
				</tr>
	
				';
        $index++;

        $total_price=$total_price + $row["product_price"];
    }

    if(mysqli_multi_query($connect, $query)) {
        echo '<h3>REXX BOOK SALES</h3><br />';
        echo '
<a href="add.php" class="btn btn-primary">Add</a>
				<table class="table table-bordered">
				<tr>
					<th >ID</th>
					<th >Customer Name</th>
					<th >Customer E-Mail</th>
					<th >Product ID</th>
					<th >Product Name</th>
					<th >Product Price</th>
					<th >Sale Date</th>
				</tr>
				';
        echo $table_data;
        echo '</table>';
    }
    ?>
    <br />

    <div>
        Total Price : <?php echo $total_price ?> €
    </div>

</div>
</body>

</html>
