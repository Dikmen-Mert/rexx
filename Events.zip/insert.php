<!DOCTYPE html>
<html>

<script src=
        "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<script src=
        "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
</script>
<style>
    .box {
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-top: 100px;
    }
    .w-100{
        width: 100%;
    }
</style>
</head>
<body>
<center>
    <?php


    $conn = mysqli_connect("localhost", "root", "", "events_db");

    // Check connection
    if($conn === false){
        die("ERROR: Could not connect. "
            . mysqli_connect_error());
    }

    $participation_id = $_REQUEST['participation_id'];
    $employee_name = $_REQUEST['employee_name'];
    $employee_mail = $_REQUEST['employee_mail'];
    $event_id = $_REQUEST['event_id'];
    $event_name = $_REQUEST['event_name'];
    $participation_fee = $_REQUEST['participation_fee'];
    $event_date = $_REQUEST['event_date'];

    $sql = "INSERT INTO events VALUES ('$participation_id','$employee_name','$employee_mail','$event_id','$event_name','$participation_fee','$event_date')";


    if(mysqli_query($conn, $sql)){
        echo "<h3>data stored in a database successfully."
            . " Please browse your localhost php my admin"
            . " to view the updated data</h3>";

        echo nl2br("\n$participation_id\n $employee_name\n "
            . "$employee_mail\n $event_id\n $event_name\n $participation_fee\n $event_date");

        echo "</br><a class='btn btn-danger' href='index.php'>Back"
            . "</a>";
    } else{
        echo "ERROR: Hush! Sorry $sql. "
            . mysqli_error($conn);
    }

    mysqli_close($conn);
    ?>
</center>
</body>

</html>