<!DOCTYPE html>
<html>
<head>
    <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
    </script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src=
            "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
    </script>
    <style>
        .box {
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 100px;
        }
        .w-100{
            width: 100%;
        }
    </style>
</head>

<body>
<div class="container box">
    <div class="row">
        <div class="col-1"></div>
        <div class="col-8"><a class="btn btn-danger" href="index.php">Back</a>
            <form action="insert.php" method="POST">
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Participation Id</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="participation_id" name="participation_id">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Employee Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="employee_name" name="employee_name">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Employee Mail</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="employee_mail" name="employee_mail">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Event Id</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="event_id" name="event_id">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Event Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="event_name" name="event_name">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Participation Fee</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="participation_fee" name="participation_fee">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Event Date</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="event_date" name="event_date" type="datetime-local"
                               name="meeting-time" value="2018-06-12T19:30"
                               min="2000-06-07T00:00" max="2036-06-14T00:00">
                    </div>
                </div>

                <input type="submit" name="save" value="Save" class="btn btn-primary">
            </form>
        </div>
        <div class="col-5"></div>
    </div>
</div>


</body>

</html>