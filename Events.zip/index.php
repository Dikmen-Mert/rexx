<!DOCTYPE html>
<html>
<head>
    <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
    </script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src=
            "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
    </script>
    <style>
        .box {
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 100px;
        }
        .w-100{
            width: 100%;
        }
    </style>
</head>


<body>
<!-- For Filter Example -->
<?php if (isset($_POST['search']))
{
    $valueToSearch= $_POST['valueToSearch'];
    $query = "SELECT * FROM 'events' WHERE 'employee_name', 'event_name','event_date' LIKE '%".$valueToSearch."%'";
    $search_result= filterTable($query);


}else{

    $query="SELECT * FROM 'events'";
    $search_result=filterTable($query);

}

function filterTable($query){

    $connect = mysqli_connect("localhost", "root", "", "events_db");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;

}

    ?>
<div class="container box">
    <h3 align="center">REXX</h3><br/>
<!-- Filter Example -->
    <form action="index.php" method="post" >
        <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
        <input type="submit" name="search" placeholder="Filter">
    </form>

    <?php

    // Server name => localhost
    // Username => root
    // Password => empty
    // Database name => test
    // Passing these 4 parameters

    $connect = mysqli_connect("localhost", "root", "", "events_db");
    $query = '';
    $table_data = '';

    // json file name
    $filename = "Events.json";

    // Read the JSON file in PHP
    $data = file_get_contents($filename);

    // Convert the JSON String into PHP Array
    $array = json_decode($data, true);
    // Extracting row by row
    foreach($array as $row) {
        // Database query to insert data
        // into database Make Multiple
        // Insert Query
        $query .="INSERT INTO events VALUES ('".$row["participation_id"]."','".$row["employee_name"]."', '".$row["employee_mail"]."', '".$row["event_id"]."', '".$row["event_name"]."', '".$row["participation_fee"]."', '".$row["event_date"]."'); ";

    }
    ?>

    <?php
    $result = mysqli_query($connect,"SELECT * FROM events");

    while($row1 = mysqli_fetch_array($result))
    {

        $table_data .= '
        <tr>
            <td>'.$row1["participation_id"].'</td>
            <td>'.$row1["employee_name"].'</td>
            <td>'.$row1["employee_mail"].'</td>
            <td>'.$row1["event_id"].'</td>
             <td>'.$row1["event_name"].'</td>
            <td>'.$row1["participation_fee"].'</td>
            <td>'.$row1["event_date"].'</td>
            <td>
					<a href="edit.php?index='.$row1["participation_id"].'" class="btn btn-success w-100 btn-sm">Edit</a>
					<a href="delete.php?index='.$row1["participation_id"].'" class="btn btn-danger w-100 btn-sm">Delete</a>
			</td>
            
        </tr>'; // Data for display on Web page


    }
    echo '<h3>Inserted JSON Data</h3><br/>';
    echo '
<a href="add.php" class="btn btn-primary">Add</a>
        <table class="table table-bordered">
            <tr>
                <th  >Participation Id</th>
                <th >Employee Name</th>
                <th >Employee Mail</th>
                <th >Event Id</th>
                 <th >Event Name</th>
                <th >Participation Fee</th>
                <th >Event Date</th>
            </tr>';
    echo $table_data; echo
    '</table>';

    ?>

    <br/>

</div>
</body>


</html>
