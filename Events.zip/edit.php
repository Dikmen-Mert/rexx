<!DOCTYPE html>
<html>
<head>
    <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js">
    </script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src=
            "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js">
    </script>
    <style>
        .box {
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 100px;
        }
        .w-100{
            width: 100%;
        }
    </style>
</head>

<body>
<?php
$conn = mysqli_connect("localhost", "root", "", "events_db");

$index = $_GET['index'];
$query = "SELECT * from events where participation_id='".$index."'";
$result = mysqli_query($conn, $query) or die ( mysqli_error($conn));

while($row = mysqli_fetch_assoc($result))
{
    $id = $row['participation_id'];
    $employee_name = $row['employee_name'];
    $employee_mail = $row['employee_mail'];
    $event_id = $row['event_id'];
    $event_name = $row['event_name'];
    $participation_fee = $row['participation_fee'];
    $event_date = $row['event_date'];
}
?>
<div class="container box">
    <div class="row">
        <div class="col-1"></div>
        <div class="col-8"><a class="btn btn-danger" href="index.php">Back</a>
            <form method="POST" action="update.php">
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Participation Id</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="participation_id" name="participation_id" value="<?php echo $id; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Employee Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="employee_name" name="employee_name" value="<?php echo $employee_name; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Employee Mail</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="employee_mail" name="employee_mail" value="<?php echo $employee_mail; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Event Id</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="event_id" name="event_id" value="<?php echo $event_id; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Event Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="event_name" name="event_name" value="<?php echo $event_name; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Participation Fee</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="participation_fee" name="participation_fee" value="<?php echo $participation_fee; ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-sm-2 col-form-label">Sale Date</label>
                    <div class="col-sm-10">
                        <input class="form-control" id="event_date" name="event_date"  value="<?php echo $event_date; ?>"
                               name="meeting-time"
                               min="2000-06-07T00:00" max="2036-06-14T00:00" >
                    </div>
                </div>

                <input type="submit" name="update" value="Update" class="btn btn-primary">
            </form>

        </div>
        <div class="col-5"></div>
    </div>
</div>
</body>

</html>