<?php
$conn = mysqli_connect("localhost", "root", "", "events_db");

$id =$_GET['index'];

$result = mysqli_query($conn, "DELETE FROM events WHERE participation_id=$id");

header("Location:index.php");
?>