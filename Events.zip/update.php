<?php

if(isset($_POST['update']))
{
    $conn = mysqli_connect("localhost", "root", "", "events_db");

    $id = mysqli_real_escape_string($conn, $_POST['participation_id']);
    $employee_name = mysqli_real_escape_string($conn, $_POST['employee_name']);
    $employee_mail = mysqli_real_escape_string($conn, $_POST['employee_mail']);
    $event_id = mysqli_real_escape_string($conn, $_POST['event_id']);
    $event_name = mysqli_real_escape_string($conn, $_POST['event_name']);
    $participation_fee = mysqli_real_escape_string($conn, $_POST['participation_fee']);
    $event_date = mysqli_real_escape_string($conn, $_POST['event_date']);

    if(empty($employee_name) || empty($employee_mail) ) {
        if(empty($employee_name)) {
            echo '<font color="red">Employee Name field is empty.</font><br>';
        }
        if(empty($employee_mail)) {
            echo '<font color="red">E-mail field is empty.</font><br>';
        }

    } else {

        $result = mysqli_query($conn, "UPDATE events SET participation_id='$id',employee_name='$employee_name',employee_mail='$employee_mail',event_id='$event_id',event_name='$event_name',participation_fee='$participation_fee',event_date='$event_date' WHERE participation_id=$id");
        header("Location: index.php");

    }
}
?>